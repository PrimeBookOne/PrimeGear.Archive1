GOTO:node_gear


goto:eof



:node_gear
   node a.out.js
count 5000
GOTO:node_gear