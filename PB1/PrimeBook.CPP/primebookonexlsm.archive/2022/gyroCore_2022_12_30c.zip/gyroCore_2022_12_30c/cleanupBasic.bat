del primebook.txt
del primemilestones.txt
