del PrimeGyroGear.exe
del primebook.txt
del primemilestones.txt
