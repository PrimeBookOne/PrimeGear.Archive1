del primebook.txt
del primemilestones.txt
del primebook.bin