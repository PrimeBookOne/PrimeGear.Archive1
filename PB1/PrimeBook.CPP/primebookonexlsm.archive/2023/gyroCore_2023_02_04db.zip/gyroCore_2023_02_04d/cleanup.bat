del primebook.txt
del primemilestones.txt
del primebook.bin
del *.fin
del *.tru

