del *.fin
del *.tru

