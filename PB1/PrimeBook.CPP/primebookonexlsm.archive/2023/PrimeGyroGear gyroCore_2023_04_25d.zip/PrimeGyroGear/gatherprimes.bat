echo off
copy *.bin primebook.new
del *.bin
rename primebook.new primebook.bin